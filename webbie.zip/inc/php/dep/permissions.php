<?php
include_once 'protected/config.php';
include_once 'Group.php';
include_once 'User.php';
include_once 'lib/HTMLPurifier.standalone.php';

$config = HTMLPurifier_Config::createDefault();
$config->set('Cache.DefinitionImpl', null);
$config->set('Core.Encoding', 'UTF-8');
$purifier = new HTMLPurifier($config);

session_start();
if (!isset($_SESSION['user']) || $_SESSION['user'] == "") {
    die('denied');
}

$settingsFile = file_exists('../../json/protected/settings.json') ? '../../json/protected/settings.json' : '../../../json/protected/settings.json';

$jsondata = file_get_contents(file_exists($settingsFile) ? $settingsFile : '../inc/json/protected/settings.json');
$websettings = json_decode($jsondata, true);

function hasPermission($permission)
{
    return $_SESSION['user']->getGroup()->hasPermission($permission);
}

function handlePermission($permission)
{
    if (!hasPermission($permission)) {
        die('no permission');
    }
}

if (isset($_GET['haspermission'])) {
    die(hasPermission($_GET['haspermission']));
}

if (isset($_GET['getSettings'])) {
    die($jsondata);
}