</div>
</div>
</div>
</div>
</div>
</div>
</div>
<script src="../inc/js/sweetalert.js"></script>
<script src="../inc/js/core.js"></script>
<script src="//cdn.rawgit.com/yahoo/xss-filters/master/dist/xss-filters.js"></script>
<script type="text/javascript">
    jQuery(document).ready(function() {
        $("time.timeago").timeago();
    });
</script>
</body>
</html>